import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const QrPixApp());

class QrPixApp extends StatelessWidget {
  const QrPixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR PiX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF1E88E5),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class PickedItem {
  final String name;
  final Uint8List bytes;
  final bool isImage;
  PickedItem(this.name, this.bytes, this.isImage);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _serverCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  final _picker = ImagePicker();

  final List<PickedItem> _items = [];
  String? _qrData;
  String _status = 'اختر الملفات';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _serverCtrl.dispose();
    _keyCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    _serverCtrl.text = p.getString('server') ?? '';
    _keyCtrl.text = p.getString('upkey') ?? '';
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server', _serverCtrl.text.trim());
    await p.setString('upkey', _keyCtrl.text.trim());
    _say('تم حفظ الإعدادات');
  }

  void _say(String s) {
    if (mounted) setState(() => _status = s);
  }

  void _changed() {
    setState(() {
      _qrData = null;
      _status = 'عدد الملفات: ${_items.length}';
    });
  }

  Future<void> _pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf', 'doc', 'docx'],
      withData: true,
    );
    if (result == null) return;
    for (final f in result.files) {
      final bytes = f.bytes;
      if (bytes == null) continue;
      final ext = (f.extension ?? '').toLowerCase();
      final isImage = ['jpg', 'jpeg', 'png', 'webp', 'gif'].contains(ext);
      _items.add(PickedItem(f.name, bytes, isImage));
    }
    _changed();
  }

  Future<void> _pickCamera() async {
    final f = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
    if (f == null) return;
    _items.add(PickedItem(f.name, await f.readAsBytes(), true));
    _changed();
  }

  void _clear() {
    setState(() {
      _items.clear();
      _qrData = null;
      _status = 'اختر الملفات';
    });
  }

  String _serverBase() => _serverCtrl.text.trim().replaceAll(RegExp(r'/$'), '');

  // Server asks Gemini (key stays on the server). Returns [x, y, w, h] or null.
  Future<List<double>?> _askCrop(Uint8List bytes) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/crop'))
        ..headers['X-Upload-Key'] = _keyCtrl.text.trim()
        ..files.add(http.MultipartFile.fromBytes(
          'file',
          bytes,
          filename: 'crop.jpg',
          contentType: MediaType('image', 'jpeg'),
        ));
      final streamed = await req.send();
      final body = await streamed.stream.bytesToString();
      final j = jsonDecode(body) as Map<String, dynamic>;
      final box = j['box'];
      if (box is List && box.length == 4) {
        return box.map((e) => (e as num).toDouble()).toList();
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Uint8List _cropAndEnhance(Uint8List bytes, List<double>? box) {
    var im = img.decodeImage(bytes);
    if (im == null) return bytes;
    if (box != null) {
      final x = (box[0] * im.width).round();
      final y = (box[1] * im.height).round();
      final w = (box[2] * im.width).round();
      final h = (box[3] * im.height).round();
      im = img.copyCrop(im, x: x, y: y, width: w, height: h);
    }
    im = img.normalize(im, min: 0, max: 255);
    return Uint8List.fromList(img.encodeJpg(im, quality: 92));
  }

  String _mimeFor(String name) {
    final ext = name.split('.').last.toLowerCase();
    switch (ext) {
      case 'pdf':
        return 'application/pdf';
      case 'doc':
        return 'application/msword';
      case 'docx':
        return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      default:
        return 'image/jpeg';
    }
  }

  Future<String> _uploadOne(Uint8List bytes, String name, String mime) async {
    final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/upload'))
      ..headers['X-Upload-Key'] = _keyCtrl.text.trim()
      ..files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: name,
        contentType: MediaType.parse(mime),
      ));

    final streamed = await req.send();
    final body = await streamed.stream.bytesToString();
    final j = jsonDecode(body) as Map<String, dynamic>;
    if (streamed.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${streamed.statusCode}');
    }
    return j['url'] as String;
  }

  Future<String> _createAlbum(List<String> urls, String code) async {
    final res = await http.post(
      Uri.parse('${_serverBase()}/album'),
      headers: {
        'Content-Type': 'application/json',
        'X-Upload-Key': _keyCtrl.text.trim(),
      },
      body: jsonEncode({'urls': urls, 'code': code}),
    );
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
    }
    return j['url'] as String;
  }

  Future<void> _generate() async {
    if (_items.isEmpty) {
      _say('اختر ملفًا واحدًا على الأقل');
      return;
    }
    if (_serverBase().isEmpty || _keyCtrl.text.trim().isEmpty) {
      _say('أدخل رابط السيرفر ومفتاح الرفع أولًا');
      return;
    }
    final code = _codeCtrl.text.trim();
    if (code.length < 4) {
      _say('اكتب رمز فتح من 4 أحرف أو أرقام على الأقل');
      return;
    }

    setState(() => _busy = true);
    try {
      final urls = <String>[];
      for (var i = 0; i < _items.length; i++) {
        final it = _items[i];
        _say('رفع ${i + 1} من ${_items.length}...');
        if (it.isImage) {
          final box = await _askCrop(it.bytes);
          final out = _cropAndEnhance(it.bytes, box);
          urls.add(await _uploadOne(out, 'qrpix.jpg', 'image/jpeg'));
        } else {
          urls.add(await _uploadOne(it.bytes, it.name, _mimeFor(it.name)));
        }
      }

      _say('إنشاء الألبوم...');
      final albumUrl = await _createAlbum(urls, code);
      if (mounted) {
        setState(() {
          _qrData = albumUrl;
          _status = 'تم. الماسح يطلب الرمز ثم يفتح ${urls.length} ملف';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveQr() async {
    final url = _qrData;
    if (url == null) return;
    try {
      final painter = QrPainter(data: url, version: QrVersions.auto, gapless: true);
      final bd = await painter.toImageData(900, format: ui.ImageByteFormat.png);
      if (bd == null) {
        _say('تعذر تجهيز صورة الـQR');
        return;
      }
      await Gal.putImageBytes(
        bd.buffer.asUint8List(),
        name: 'qr_pix_${DateTime.now().millisecondsSinceEpoch}.png',
      );
      _say('تم حفظ الـQR في المعرض');
    } catch (e) {
      _say('تعذر الحفظ: $e');
    }
  }

  Widget _card(String title, Widget child) {
    return Card(
      color: const Color(0xCC0B1D3A),
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 18, color: Color(0xFFF1D77A), fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            child,
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {bool obscure = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        obscureText: obscure,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          Positioned.fill(child: Container(color: Colors.black.withOpacity(0.55))),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Center(
                  child: Text('QR PiX',
                      style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF64B5F6))),
                ),
                const SizedBox(height: 16),
                _card(
                  '1. الملفات (صور، PDF، Word)',
                  Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _busy ? null : _pickFiles,
                              icon: const Icon(Icons.folder_open),
                              label: const Text('اختيار ملفات'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _busy ? null : _pickCamera,
                              icon: const Icon(Icons.camera_alt),
                              label: const Text('كاميرا'),
                            ),
                          ),
                        ],
                      ),
                      if (_items.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            for (final it in _items)
                              it.isImage
                                  ? ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: Image.memory(it.bytes,
                                          width: 70, height: 70, fit: BoxFit.cover),
                                    )
                                  : Container(
                                      width: 70,
                                      height: 70,
                                      padding: const EdgeInsets.all(4),
                                      decoration: BoxDecoration(
                                        color: Colors.white10,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Center(
                                        child: Text(it.name,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(fontSize: 11)),
                                      ),
                                    ),
                          ],
                        ),
                        TextButton(onPressed: _busy ? null : _clear, child: const Text('مسح الكل')),
                      ],
                    ],
                  ),
                ),
                _card(
                  '2. الإعدادات',
                  Column(
                    children: [
                      _field(_serverCtrl, 'رابط السيرفر'),
                      _field(_keyCtrl, 'مفتاح الرفع', obscure: true),
                      OutlinedButton(onPressed: _saveSettings, child: const Text('حفظ الإعدادات')),
                    ],
                  ),
                ),
                _card(
                  '3. رمز فتح الألبوم',
                  Column(
                    children: [
                      _field(_codeCtrl, 'الرمز (4 أحرف أو أرقام أو أكثر)'),
                    ],
                  ),
                ),
                _card(
                  '4. الـQR',
                  Column(
                    children: [
                      FilledButton(
                        onPressed: _busy ? null : _generate,
                        child: Text(_busy ? 'جاري العمل...' : 'توليد QR'),
                      ),
                      const SizedBox(height: 10),
                      Text(_status, textAlign: TextAlign.center),
                      if (_qrData != null) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(12),
                          color: Colors.white,
                          child: QrImageView(data: _qrData!, size: 260),
                        ),
                        const SizedBox(height: 8),
                        FilledButton.icon(
                          onPressed: _saveQr,
                          icon: const Icon(Icons.save_alt),
                          label: const Text('حفظ الـQR في المعرض'),
                        ),
                        const SizedBox(height: 8),
                        SelectableText(_qrData!, style: const TextStyle(fontSize: 12)),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
